<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\BisnisController;
use App\Models\Support;
use App\Models\Hour;
use App\Models\Day;
use App\Models\Room;
use App\Models\Lecture;
use App\Models\Wtb;
use App\Models\Course;
use App\Models\Schedule;
use Illuminate\Support\Facades\DB;
class ProccessController extends Controller
{

    protected $m_dosen;
    protected $m_matakuliah;
    protected $m_ruang;
    protected $m_jam;
    protected $m_hari;
    protected $m_pengampu;
    protected $m_waktu_tidak_bersedia;
    protected $m_jadwalkuliah;
    protected $bisnisController;
    
    // public function __construct(
    //     Lecture $m_dosen,
    //     Course $m_matakuliah,
    //     Room $m_ruang,
    //     Hour $m_jam,
    //     Day $m_hari,
    //     Support $m_pengampu,
    //     Wtb $m_waktu_tidak_bersedia,
    //     Schedule $m_jadwalkuliah
    // ) {
    //     $this->m_dosen = $m_dosen;
    //     $this->m_matakuliah = $m_matakuliah;
    //     $this->m_ruang = $m_ruang;
    //     $this->m_jam = $m_jam;
    //     $this->m_hari = $m_hari;
    //     $this->m_pengampu = $m_pengampu;
    //     $this->m_waktu_tidak_bersedia = $m_waktu_tidak_bersedia;
    //     $this->m_jadwalkuliah = $m_jadwalkuliah;
    // } 
    // function __construct()
    // {
    //     parent::__construct();
	// 	$this->load->model(array('m_dosen',
	// 							 'm_matakuliah',
	// 							 'm_ruang',
	// 							 'm_jam',
	// 							 'm_hari',
	// 							 'm_pengampu',
	// 							 'm_waktu_tidak_bersedia',
	// 							 'm_jadwalkuliah'));
	// 	include_once("genetik.php");
	// 	define('IS_TEST','FALSE');
    // }
    
    
   
       
   
        
        // $jumlah_generasi = config('config.jumlah_generasi');
        // // dd($jumlah_generasi);
        // $genetik = new BisnisController(); //kode jam dhuhur
        // $genetik->ambildata();
        // $genetik->inisialiasi();

        // // dd($genetik);
      public  function __construct(Lecture $lecture, Course $course, Room $room, Hour $hour, Day $day, Support $support, Wtb $wtb, Schedule $schedule)
        {
        //    $genetik = new BisnisController($jenis_semester, $tahun_akademik, $populasi, $crossOver, $mutasi, $kode_jumat, $range_jumat, $kode_dhuhur);
        //  $genetik->__construct($jenis_semester, $tahun_akademik, $populasi, $crossOver, $mutasi, $kode_jumat, $range_jumat, $kode_dhuhur);
            $this->m_dosen = $lecture;
            $this->m_matakuliah = $course;
            $this->m_ruang = $room;
            $this->m_jam = $hour;
            $this->m_hari = $day;
            $this->m_pengampu = $support;
            $this->m_waktu_tidak_bersedia = $wtb;
            $this->m_jadwalkuliah = $schedule;
    
           
           
        }
      public  function index(){
		
            $data = array();
            
            if(!empty($_POST)){
                $this->form_validation->set_rules('semester_tipe','Semester','xss_clean|required');
                $this->form_validation->set_rules('tahun_akademik','Tahun Akademik','xss_clean|required');
                $this->form_validation->set_rules('jumlah_populasi','Jumlah Populiasi','xss_clean|required');
                $this->form_validation->set_rules('probabilitas_crossover','Probabilitas CrossOver','xss_clean|required');
                $this->form_validation->set_rules('probabilitas_mutasi','Probabilitas Mutasi','xss_clean|required');
                $this->form_validation->set_rules('jumlah_generasi','Jumlah Generasi','xss_clean|required');
                
                if($this->form_validation->run() == TRUE)
                {				
                    //tempat keajaiban dimulai. SEMANGAAAAAATTTTTTT BANZAIIIIIIIIIIIII !
                    
                    $jenis_semester = $this->input->post('semester_tipe');
                    $tahun_akademik = $this->input->post('tahun_akademik');
                    $jumlah_populasi = $this->input->post('jumlah_populasi');
                    $crossOver = $this->input->post('probabilitas_crossover');
                    $mutasi = $this->input->post('probabilitas_mutasi');
                    $jumlah_generasi = $this->input->post('jumlah_generasi');
                    
                    $data['semester_tipe'] = $jenis_semester;
                    $data['tahun_akademik'] = $tahun_akademik;
                    $data['jumlah_populasi'] = $jumlah_populasi;
                    $data['probabilitas_crossover'] = $crossOver;
                    $data['probabilitas_mutasi'] = $mutasi;
                    $data['jumlah_generasi'] = $jumlah_generasi;
                    
                    // $rs_data = $this->db->query("SELECT   a.kode,"
                    //                     . "       b.sks,"
                    //                     . "       a.kode_dosen,"
                    //                     . "       b.jenis, a.kelas "
                    //                     . "FROM pengampu a "
                    //                     . "LEFT JOIN matakuliah b "
                    //                     . "ON a.kode_mk = b.kode "
                    //                     . "WHERE b.semester%2 = $jenis_semester "
                    //                     . "      AND a.tahun_akademik = '$tahun_akademik'");
                    $rs_data = DB::table('pengampu AS a')
                     ->select('a.kode', 'b.sks', 'a.kode_dosen', 'b.jenis', 'a.kelas')
                    ->leftJoin('matakuliah AS b', 'a.kode_mk', '=', 'b.kode')
                      ->where(DB::raw('b.semester % 2'), $jenis_semester)
                    ->where('a.tahun_akademik', $tahun_akademik)
                   ->get();
                    if($rs_data->num_rows() == 0){
                        
                        $data['msg'] = 'Tidak Ada Data dengan Semester dan Tahun Akademik ini <br>Data yang tampil dibawah adalah data dari proses sebelumnya';
                   // dd($rs_data);    
                        //redirect(base_url() . 'web/penjadwalan','reload');
                    }else{
                        $genetik = new BisnisController($jenis_semester,
                                               $tahun_akademik,
                                               $jumlah_populasi,
                                               $crossOver,
                                               $mutasi,
                                               //~~~~~~BUG!~~~~~~~
                                               /*										   
                                                1 senin 5
                                                2 selasa 4
                                                3 rabu 3
                                                4 kamis 2
                                                5 jumat 1										    
                                               */
                                               5,//kode hari jumat										   
                                               '4-5-6', //kode jam jumat
                                               //jam dhuhur tidak dipake untuk sementara
                                               6); //kode jam dhuhur
       
					$found = false;
					
					for($i = 0;$i < $jumlah_generasi;$i++ ){
						$fitness = $genetik->HitungFitness();
						//if($i == 100){
						//	var_dump($fitness);
						//	exit();
						//}
						
						$genetik->Seleksi($fitness);
						$genetik->StartCrossOver();
						
						$fitness_akhir[$i] = $fitnessAfterMutation = $genetik->Mutasi();

						//$fitnessAfterMutation = $genetik->Mutasi();
						
						for ($j = 0; $j < count($fitnessAfterMutation); $j++){
							//test here
							if($fitnessAfterMutation[$j] == 1){
								Schedule::truncate();
								//$this->db->query("TRUNCATE TABLE jadwalkuliah");
								
								$jadwal_kuliah = array(array());
								$jadwal_kuliah = $genetik->GetIndividu($j);
                                $fitnessok[$j] = $genetik->GetIndividu($j);
                                $fitness = $fitnessok[$j];
                                
								
								
								for($k = 0; $k < count($jadwal_kuliah);$k++){
									
									$kode_pengampu = intval($jadwal_kuliah[$k][0]);
									$kode_jam = intval($jadwal_kuliah[$k][1]);
									$kode_hari = intval($jadwal_kuliah[$k][2]);
									$kode_ruang = intval($jadwal_kuliah[$k][3]);
									// $bentrok = intval($jadwal_kuliah[$k][5]);
									DB::table('jadwalkuliah')->insert([
                                        'kode_pengampu' => $kode_pengampu,
                                        'kode_jam' => $kode_jam,
                                        'kode_hari' => $kode_hari,
                                        'kode_ruang' => $kode_ruang,
                                    ]);
                                    //$this->db->query("INSERT INTO jadwalkuliah(kode_pengampu,kode_jam,kode_hari,kode_ruang) ".
									//				 "VALUES($kode_pengampu,$kode_jam,$kode_hari,$kode_ruang)");
									
									
								}
								
								//var_dump($jadwal_kuliah);
								//exit();
								
								$found = true;								
							}
							
							if($found){break;}
						}
						
						if($found){break;}
					}
                    echo "<pre>";print_r($fitness_akhir); exit(); //buat liat fitness setelah mutasi
					if(!$found){
						$data['msg'] = 'Tidak Ditemukan Solusi Optimal';
					}
					
				}
			}else{
				$data['msg'] = validation_errors();
			}
		}
                    
                    
        
    
    $data['page_name'] = 'penjadwalan';
		$data['page_title'] = 'Penjadwalan';
		// $jadwal = $this->db->query("SELECT jk.*, pm.kode_dosen, pm.kelas , mk.sks
		// 							FROM `jadwalkuliah` jk 
		// 							LEFT JOIN pengampu pm ON jk.kode_pengampu = pm.kode
		// 							LEFT JOIN matakuliah mk ON pm.kode_mk = mk.kode
		// 							")->result();
        $jadwal = DB::table('jadwalkuliah')
        ->select('jadwalkuliah.*', 'pengampu.kode_dosen', 'pengampu.kelas', 'matakuliah.sks')
        ->leftJoin('pengampu', 'jadwalkuliah.kode_pengampu', '=', 'pengampu.kode')
        ->leftJoin('matakuliah', 'pengampu.kode_mk', '=', 'matakuliah.kode')
        ->get();
		$jumlahJadwal = count($jadwal);
		$bentrok = array();
		for ($i=0; $i < $jumlahJadwal ; $i++) {
			$bentrok[$i] = 0; 
			$jam_a = intval($jadwal[$i]->kode_jam);
          	$hari_a = intval($jadwal[$i]->kode_hari);
          	$ruang_a = intval($jadwal[$i]->kode_ruang);
          	$dosen_a = intval($jadwal[$i]->kode_dosen); 
          	$kelas_a = $jadwal[$i]->kelas;
          	$sks = $jadwal[$i]->sks;

			for ($j=0; $j < $jumlahJadwal ; $j++) { 
				$jam_b = intval($jadwal[$j]->kode_jam);
	          	$hari_b = intval($jadwal[$j]->kode_hari);
	          	$ruang_b = intval($jadwal[$j]->kode_ruang);
	          	$dosen_b = intval($jadwal[$j]->kode_dosen); 
	          	$kelas_b = $jadwal[$j]->kelas;
	          	if ($i == $j){
                    continue;
	          	}

	          	// cek ruangan
	          	 if ($jam_a == $jam_b &&
                    $hari_a == $hari_b &&
                    $ruang_a == $ruang_b)
                {
                    $bentrok[$i] = 1;

                }
                if ($sks >= 2)
                {
                    if ($jam_a + 1 == $jam_b &&
                        $hari_a == $hari_b &&
                        $ruang_a == $ruang_b)
                    {
                         $bentrok[$i] = 1;
                    }
                }
                if ($sks >= 3)
                {
                    if ($jam_a + 2 == $jam_b &&
                        $hari_a == $hari_b &&
                        $ruang_a == $ruang_b)
                    {
                         $bentrok[$i] = 1;
                    }
                }
                if ($sks >= 4)
                {
                    if ($jam_a + 3 == $jam_b &&
                        $hari_a == $hari_b &&
                        $ruang_a == $ruang_b)
                    {
                         $bentrok[$i] = 1;
                    }
                }
                if ($sks >= 5)
                {
                    if ($jam_a + 4 == $jam_b &&
                        $hari_a == $hari_b &&
                        $ruang_a == $ruang_b)
                    {
                         $bentrok[$i] = 1;
                    }
                }

                //cek kelas
                if ($jam_a == $jam_b &&
                    $hari_a == $hari_b &&
                    $kelas_a == $kelas_b)
                {
                    $bentrok[$i] = 1;

                }
                 if ($sks >= 2)
                {
                    if ($jam_a + 1 == $jam_b &&
                        $hari_a == $hari_b &&
                       $kelas_a == $kelas_b)
                    {
                        $bentrok[$i] = 1;
                    }
                }
                if ($sks >= 3)
                {
                    if ($jam_a + 2 == $jam_b &&
                        $hari_a == $hari_b &&
                       $kelas_a == $kelas_b)
                    {
                        $bentrok[$i] = 1;
                    }
                }
                if ($sks >= 4)
                {
                    if ($jam_a + 3 == $jam_b &&
                        $hari_a == $hari_b &&
                       $kelas_a == $kelas_b)
                    {
                        $bentrok[$i] = 1;
                    }
                }
                if ($sks >= 5)
                {
                    if ($jam_a + 4 == $jam_b &&
                        $hari_a == $hari_b &&
                       $kelas_a == $kelas_b)
                    {
                        $bentrok[$i] = 1;
                    }
                }

                //cek dosen
                if (
                //ketika jam, hari, dan dosen sama
                    $jam_a == $jam_b && 
                    $hari_a == $hari_b && 
                    $dosen_a == $dosen_b)
                {
                  $bentrok[$i] = 1;
                }
                if ($sks >= 2) {
                    if (
                    //ketika jam, hari, dan dosen sama
                      ($jam_a + 1) == $jam_b && 
                      $hari_a == $hari_b && 
                      $dosen_a == $dosen_b)
                    {
                      $bentrok[$i] = 1;
                    }
                }
                if ($sks >= 3) {
                    if (
                    //ketika jam, hari, dan dosen sama
                      ($jam_a + 2) == $jam_b && 
                      $hari_a == $hari_b && 
                      $dosen_a == $dosen_b)
                    {
                      $bentrok[$i] = 1;
                    }
                }
                if ($sks >= 4) {
                    if (
                    //ketika jam, hari, dan dosen sama
                      ($jam_a + 3) == $jam_b && 
                      $hari_a == $hari_b && 
                      $dosen_a == $dosen_b)
                    {
                      $bentrok[$i] = 1;
                    }
                }
                if ($sks >= 5) {
                    if (
                    //ketika jam, hari, dan dosen sama
                      ($jam_a + 4) == $jam_b && 
                      $hari_a == $hari_b && 
                      $dosen_a == $dosen_b)
                    {
                      $bentrok[$i] = 1;
                    }
                }

			}
		}

		// print_r($bentrok); exit();
       
		$data['bentrok'] = $bentrok; // kalo misal ada kelas / ruangan / dosen bentrok, nilainya di array ini jadi 1 
		$rs_jadwal = $this->m_jadwalkuliah->get();
        $data['rs_jadwal'] = $rs_jadwal;
		// print_r($data['rs_jadwal']->result()); exit();
        //dd($bentrok);
		return view('schedule.index', ['data' => $data, 'rs_jadwal' => $rs_jadwal, 'bentrok'=>$bentrok]);

	}

	
	
	function excel_report(){
		$query = $this->m_jadwalkuliah->get();
		if(!$query)
            return false;
		
		// Starting the PHPExcel library
        $this->load->library('PHPExcel');
        $this->load->library('PHPExcel/IOFactory');
		
		$objPHPExcel = new PHPExcel();
        $objPHPExcel->getProperties()->setTitle("export")->setDescription("none");
 
        $objPHPExcel->setActiveSheetIndex(0);
		 // Field names in the first row
        $fields = $query->list_fields();
        $col = 0;
        foreach ($fields as $field)
        {
            $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col, 1, $field);
            $col++;
        }
		
		// Fetching the table data
        $row = 2;
        foreach($query->result() as $data)
        {
            $col = 0;
            foreach ($fields as $field)
            {
                $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col, $row, $data->$field);
                $col++;
            }
 
            $row++;
        }
		
		$objPHPExcel->setActiveSheetIndex(0);
 
        $objWriter = IOFactory::createWriter($objPHPExcel, 'Excel5');
 
        // Sending headers to force the user to download the file
        header('Content-Type: application/vnd.ms-excel');
        header('Content-Disposition: attachment;filename="Hasil Penjadwalan_'.date('dMy').'.xls"');
        header('Cache-Control: max-age=0');
 
        $objWriter->save('php://output');
    return view('proccess.index');
}
}
